﻿using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace ThePantry
{
    /// <summary>
    /// Interaction logic for ViewRecipes.xaml
    /// </summary>
    public partial class ViewRecipes : Window
    {
        private List<Recipe> recipes;

        public ViewRecipes(List<Recipe> recipes)
        {
            InitializeComponent();

            this.recipes = recipes.OrderBy(r => r.Name).ToList();
            RecipeListBox.ItemsSource = this.recipes;
            RecipeListBox.DisplayMemberPath = "Name";
        }

        private void RecipeListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (!(RecipeListBox.SelectedItem is Recipe selectedRecipe))
                return;

            RecipeDetailsTextBlock.Text = $"Recipe: {selectedRecipe.Name}\n" +
                                          $"Total Calories: {selectedRecipe.TotalCalories()}\n" +
                                          $"Ingredients:\n{string.Join("\n", selectedRecipe.Ingredient.Select((ing, i) => $"- {selectedRecipe.Amount[i]} {selectedRecipe.Measurement[i]} of {ing}"))}\n" +
                                          $"Instructions:\n{string.Join("\n", selectedRecipe.Steps.Select((step, i) => $"{i + 1}. {step}"))}";

            RecipeDetailsTextBlock.Visibility = Visibility.Visible;
        }
    }
}
