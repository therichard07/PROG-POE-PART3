﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThePantry
{
    public class Recipe
    {
        public string Name { get; set; }
        public int ingredientCalories { get; set; }
        public string[] Ingredient { get; set; }
        public double[] Original { get; set; }
        public double[] Amount { get; set; }
        public string[] Measurment { get; set; }
        public int StepCount { get; set; }
        public string[] Steps { get; set; }
        public double[] Calories { get; set; }
        public string[] foodGroup { get; set; }
        public double[] totalCalories { get; set; }

        public delegate void ceMessage(string message);
        public event ceMessage CE;

        public double TotalCalories()
        {
            double tc = 0;
            for (int i = 0; i < ingredientCalories; i++)
            {
                tc += Calories[i];
            }

            if (tc > 300)
            {
                CE?.Invoke("It's over 300 (" + tc + ")...that's A LOT of calories");
            }
            return tc;
        }
    }