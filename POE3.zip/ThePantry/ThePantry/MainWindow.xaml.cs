﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ThePantry
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private List<Recipe> recipes = new List<Recipe>();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void AddRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            AddRecipeWindow addRecipeWindow = new AddRecipeWindow();
            addRecipeWindow.ShowDialog();

            if (addRecipeWindow.Recipe != null)
            {
                recipes.Add(addRecipeWindow.Recipe);
                MessageBox.Show("Recipe added successfully!");
            }
        }

        private void ViewRecipesButton_Click(object sender, RoutedEventArgs e)
        {
            RecipeListBox.Items.Clear();
            if (recipes.Count == 0)
            {
                MessageBox.Show("No recipes to display.");
                return;
            }

            recipes = recipes.OrderBy(r => r.Name).ToList();

            RecipeListBox.Visibility = Visibility.Visible;
            RecipeDetailsTextBlock.Visibility = Visibility.Collapsed;

            foreach (var recipe in recipes)
            {
                RecipeListBox.Items.Add(recipe.Name);
            }
        }

        private void RecipeListBox_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (RecipeListBox.SelectedItem == null)
                return;

            var selectedRecipeName = RecipeListBox.SelectedItem.ToString();
            var recipe = recipes.FirstOrDefault(r => r.Name == selectedRecipeName);

            if (recipe != null)
            {
                RecipeDetailsTextBlock.Text = $"Recipe: {recipe.Name}\n" +
                    $"Total Calories: {recipe.TotalCalories()}\n" +
                    $"Ingredients:\n{string.Join("\n", recipe.Ingredient.Select((ing, i) => $"- {recipe.Amount[i]} {recipe.Measurment[i]} of {ing}"))}\n" +
                    $"Instructions:\n{string.Join("\n", recipe.Steps.Select((step, i) => $"{i + 1}. {step}"))}";

                RecipeDetailsTextBlock.Visibility = Visibility.Visible;
            }
        }

        private void ChangeQuantityButton_Click(object sender, RoutedEventArgs e)
        {
            if (recipes.Count == 0)
            {
                MessageBox.Show("No recipes to adjust.");
                return;
            }

            Recipe recipe = recipes.FirstOrDefault();
            if (recipe == null)
            {
                MessageBox.Show("No recipe selected.");
                return;
            }

            if (recipe.Original == null)
            {
                recipe.Original = new double[recipe.ingredientCalories];
                Array.Copy(recipe.Amount, recipe.Original, recipe.ingredientCalories);
            }

            PortionAdjustWindow adjustPortionsWindow = new PortionAdjustWindow(recipe);
            adjustPortionsWindow.ShowDialog();

            MessageBox.Show("Portion size adjusted.");
        }

        private void DeleteRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            if (RecipeListBox.SelectedItem == null)
            {
                MessageBox.Show("No recipe selected.");
                return;
            }

            Recipe recipe = RecipeListBox.SelectedItem as Recipe;

            if (recipe == null)
            {
                MessageBox.Show("Invalid recipe selected.");
                return;
            }

            DeleteRecipe deleteRecipeWindow = new DeleteRecipe(recipe);
            deleteRecipeWindow.ShowDialog();

            if (deleteRecipeWindow.DeleteConfirmed)
            {
                recipes.Remove(recipe);
                MessageBox.Show("Recipe deleted.");
            }
        }
