﻿using System;
using System.Collections.Generic;
using System.Windows;

namespace ThePantry
{
    /// <summary>
    /// Interaction logic for DeleteRecipe.xaml
    /// </summary>
    public partial class DeleteRecipe : Window
    {
        private List<Recipe> recipes;

        public DeleteRecipe(List<Recipe> recipes)
        {
            InitializeComponent();
            this.recipes = recipes;
            RecipeComboBox.ItemsSource = recipes;
            RecipeComboBox.DisplayMemberPath = "Name";
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            if (RecipeComboBox.SelectedItem is Recipe selectedRecipe)
            {
                if (recipes.Contains(selectedRecipe))
                {
                    recipes.Remove(selectedRecipe);
                    MessageBox.Show("Recipe deleted.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Selected recipe not found in the list.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                MessageBox.Show("Please select a recipe to delete.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
