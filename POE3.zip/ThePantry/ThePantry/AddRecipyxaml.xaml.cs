﻿using System;
using System.Linq;
using System.Windows;

namespace ThePantry
{
    /// <summary>
    /// Interaction logic for AddRecipeWindow.xaml
    /// </summary>
    public partial class AddRecipeWindow : Window
    {
        public Recipe Recipe { get; private set; }

        public AddRecipeWindow()
        {
            InitializeComponent();
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Recipe = new Recipe
                {
                    Name = RecipeNameTextBox.Text,
                    ingredientCalories = int.Parse(IngredientCountTextBox.Text),
                    Ingredient = IngredientTextBox.Text.Split(',').Select(i => i.Trim()).ToArray(),
                    Amount = AmountTextBox.Text.Split(',').Select(a => double.Parse(a.Trim())).ToArray(),
                    Measurement = MeasurementTextBox.Text.Split(',').Select(m => m.Trim()).ToArray(),
                    Calories = CaloriesTextBox.Text.Split(',').Select(c => double.Parse(c.Trim())).ToArray(),
                    FoodGroup = FoodGroupTextBox.Text.Split(',').Select(f => f.Trim()).ToArray(),
                    StepCount = int.Parse(StepCountTextBox.Text),
                    Steps = StepTextBox.Text.Split(',').Select(s => s.Trim()).ToArray()
                };

                // Delegate for message
                Recipe.CE += message => MessageBox.Show(message);

                DialogResult = true;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}
