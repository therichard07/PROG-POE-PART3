﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ThePantry
{
    /// <summary>
    /// Interaction logic for PortionAdjustxaml.xaml
    /// </summary>
    public partial class PortionAdjustWindow : Window
    {
        private Recipe _recipe;

        public PortionAdjustWindow(Recipe recipe)
        {
            InitializeComponent();
            _recipe = recipe;
        }

        private void InitializeComponent()
        {
            throw new NotImplementedException();
        }

        private void AdjustPortion(double factor)
        {
            for (int i = 0; i < _recipe.ingredientCalories; i++)
            {
                _recipe.Amount[i] = _recipe.Original[i] * factor;
            }
        }

        private void HalfButton_Click(object sender, RoutedEventArgs e)
        {
            AdjustPortion(0.5);
            Close();
        }

        private void DoubleButton_Click(object sender, RoutedEventArgs e)
        {
            AdjustPortion(2);
            Close();
        }

        private void TripleButton_Click(object sender, RoutedEventArgs e)
        {
            AdjustPortion(3);
            Close();
        }

        private void RevertButton_Click(object sender, RoutedEventArgs e)
        {
            Array.Copy(_recipe.Original, _recipe.Amount, _recipe.ingredientCalories);
            Close();
        }
    }


